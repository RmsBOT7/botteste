const help = (prefix) => {
	return `

╔─━━━━━━░★░━━━━━━─╗
   𖤍🅖🅤🅘🅛🅗🅔🅡🅜🅔 🅧𖤍
╚─━━━━━━░★░━━━━━━─╝

➸ BOT_DO_GUI( ͡° ͜ʖ ͡°) : *「🤖」*
➸ Status: *「 Online 」*

       • ──── ✾ ──── •
        *FIGURINHAS* ✪
       • ──── ✾ ──── •
      
➸ Comando : *.sticker* ou *.stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda

➸ Comando : *.sticker nobg* ou *.stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda/n
➸ Comando : *.toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta

➸ Comando : *.tsticker* ou *.tstiker*
➸ útil em : converter texto em adesivo
➸ uso : *.tsticker seu texto aqui*

       • ──── ✾ ──── •
        *OUTROS...* 🤖
       • ──── ✾ ──── •
      


       • ─── ✾ ─── •
         *GRUPO* 🤖
       • ─── ✾ ─── •
      
➸ Comando : *.linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando

➸ Comando : *.marcar*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando

➸ Nota : Você precisa ser administrador do grupo
➸ Comando : *.add*
➸ útil em : adicionar membro ao grupo
➸ uso : *.add 5585xxxxx*

➸ Nota : o bot precisa ser admin!

➸ Comando : *.kick*
➸ útil em : remover membros do grupo
➸ uso : *.kick e o @da pessoa*

➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *.promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *.promote e o @da pessoa*

➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *.demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *.demote e o @da pessoa*

➸ Nota : Você precisa ser admin e o bot também

       ╔─━━━━━━░★░━━━━━━─╗
          𖤍🅖🅤🅘🅛🅗🅔🅡🅜🅔 🅧𖤍
       ╚─━━━━━━░★░━━━━━━─╝

➸ *.help1
➸ *${prefix}help1* ♔
    

╔════════════════════
  DUVIDAS? 👇
  WA.me/554291276766
  WA.me/552799013169
  
╚════════════════════`
}

exports.help = help






