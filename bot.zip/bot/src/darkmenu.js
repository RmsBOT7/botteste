const darkmenu = (prefix) => {
	return `

    ╔─━━━━━━░★░━━━━━━─╗
   𖤍🅖🅤🅘🅛🅗🅔🅡🅜🅔 🅧𖤍
╚─━━━━━━░★░━━━━━━─╝
➸ *.marcar*
➸ *.marcar2*
➸ *.marcar3*
➸ *.dono*
➸ *.porno*
➸ *.boanoite*
➸ *.bomdia*
➸ *.boatarde*
➸ *.mia*
➸ *.mia1*
➸ *.mia2*
➸ *.belle*
➸ *.belle1*
➸ *.belle2*
➸ *.belle3*
➸ *.reislin*
➸ *.limpar*
➸ *.ts (texto que deseja transmitir)*
}

exports.darkmenu = darkmenu








